package UpLoadData;

import java.awt.image.BufferedImage;
import java.nio.Buffer;
import java.util.ArrayList;
import java.util.List;

public class Animation {
    private List frames;
    private int frameIn = 0;
    private int time;
    private long previousTime = 0;
    public Animation(int time)
    {
        this.time = time;
        frames = new ArrayList<BufferedImage>();
    }
    public void update()
    {
       if (System.currentTimeMillis() - previousTime > time){
            frameIn++;
            if (frameIn>=frames.size()){
                frameIn = 0;
           }
            previousTime = System.currentTimeMillis();
       }

    }
    public void addF(BufferedImage frame){
        frames.add(frame);

    }
    public BufferedImage getFrame()
    {
        if (frames.size()>0)
        {
            return (BufferedImage) frames.get(frameIn);
        }
        return null;
    }


}
