package ObjectGame;

import GameView.View;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.function.BiFunction;

import static GameView.View.limitY;

public class OBJ_Way {
    private BufferedImage imgWay1, imgWay2, imgWay3;
    private List<ImgWay> listImg;
    private Random rd;
    public OBJ_Way(View v)  {
        try {
            rd = new Random();
            imgWay1 = ImageIO.read(getClass().getResourceAsStream("/data/land1.png"));
            imgWay2 = ImageIO.read(getClass().getResourceAsStream("/data/land2.png"));
            imgWay3 = ImageIO.read(getClass().getResourceAsStream("/data/land3.png"));
            listImg = new ArrayList<ImgWay>();
            int sizeOfWay = 700 / imgWay1.getWidth() +5;
            for (int i = 0; i< sizeOfWay; i++)
            {
                ImgWay imgWay = new ImgWay();
                imgWay.posX = (int)(i * imgWay1.getWidth());
                imgWay.img = getImgWay();
                listImg.add(imgWay);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }

    private BufferedImage getImgWay()
    {
        int i = rd.nextInt(6);
        switch (i)
        {
            case 0:
                return imgWay1;
            case 2:
                return imgWay3;
            default:
                return imgWay2;
        }
    }
    public void updateWay(double i)
    {
        for (ImgWay imgWay: listImg) {
            imgWay.posX -= 6*i;
        }
        ImgWay firstEml = listImg.get(0);
        if (listImg.get(0).posX + imgWay1.getWidth() < 0)
        {
            firstEml.posX = listImg.get(listImg.size()-1).posX + imgWay1.getWidth();
            listImg.add(listImg.get(0));
            listImg.remove(0);
        }
    }
    public void draw(Graphics g)
    {
        for (ImgWay imgWay:listImg) {
            g.drawImage(imgWay.img,imgWay.posX,(int)limitY - 20,null);
        }

    }
    private class ImgWay{
        int posX;
        BufferedImage img;

    }
}
