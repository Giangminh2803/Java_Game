package ObjectGame;

import GameView.View;
import UpLoadData.Animation;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.util.ResourceBundle;

import static GameView.View.*;



public class OBJ_Character{

    private float posX = 0;
    private float posY = 0;
    private float speedY = 0;
    private Animation animation_Run;
    private BufferedImage chaImg;
    private Rectangle rect;
    private boolean live = true;
    private BufferedImage imgDead;


    public OBJ_Character(){
        try {
            animation_Run = new Animation(100);
            animation_Run.addF(ImageIO.read(getClass().getResourceAsStream("/data/main-character1.png")));
            animation_Run.addF(ImageIO.read(getClass().getResourceAsStream("/data/main-character2.png")));
            animation_Run.addF(ImageIO.read(getClass().getResourceAsStream("/data/main-character3.png")));

                imgDead = ImageIO.read(getClass().getResourceAsStream("/data/main-character4.png"));

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        rect = new Rectangle();

    }

    public Rectangle Colision()
    {
        return rect;
    }

    public void update()
    {
        animation_Run.update();
        if (posY >= limitY-animation_Run.getFrame().getHeight()){
            speedY = 0;
            posY = limitY-animation_Run.getFrame().getHeight();
        }else {
            speedY += speedDrop;
            posY += speedY;
    }
        rect.x = (int) posX;
        rect.y = (int) posY;
        rect.width = animation_Run.getFrame().getWidth()-10;
        rect.height = animation_Run.getFrame().getHeight()-10;
    }

    public void draw(Graphics g){
        g.setColor(Color.BLACK);
//        g.drawRect((int)posX,(int)posY,chacRun.getFrame().getWidth(),chacRun.getFrame().getHeight());
        g.drawImage(animation_Run.getFrame(), (int)posX, (int)posY,null);
    }
    public  void drawDead(Graphics g)
    {
        g.setColor(Color.BLACK);
        g.drawImage(imgDead,(int)posX, (int)posY,null);
    }


    public void jump()
    {
        if (posY == limitY-animation_Run.getFrame().getHeight()) {
            speedY = -12;
            posY += speedY;



       }
    }

    public float getPosX() {
        return posX;
    }
    public void setPosX(float posX) {
        this.posX = posX;
    }

    public void setPosY(float posY) {
        this.posY = posY;
    }

    public void setLive(boolean live){
        this.live = live;
    }
    public boolean getLive(){
        return this.live;
    }
}


