package ObjectGame;

import java.awt.*;

public abstract class Enemy {
    public abstract Rectangle Colision();
    public abstract void draw(Graphics g);
    public abstract void update(double i);
    public abstract boolean Out();
    public abstract boolean isOver();
    public abstract boolean isScore();
    public abstract void setScore(boolean isScore);


}
