package ObjectGame;

import GameView.View;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class EnemyManager {
    private List<Enemy> ens, ens1;
    private Random random;
    private BufferedImage imgCac1,imgCac2,imgCacb1,imgCacb2;
    private OBJ_Character character;
    private OBJ_Bird bird;
    private View view;


    public EnemyManager(OBJ_Character character, View view)
    {
        this.view = view;
        this.character = character;
        bird = new OBJ_Bird(character);
        ens = new ArrayList<Enemy>();
        ens1 = new ArrayList<Enemy>();

        OBJ_Cactus cactus = new OBJ_Cactus(character);
        try {
            imgCac1 = ImageIO.read(getClass().getResourceAsStream("/data/cactus1.png"));
            imgCac2 = ImageIO.read(getClass().getResourceAsStream("/data/cactus2.png"));

        } catch (IOException e) {
            e.printStackTrace();
        }
        OBJ_Bird bird = new OBJ_Bird(character);
        try {
            imgCacb1 = ImageIO.read(getClass().getResourceAsStream("/data/0.png"));
            imgCacb2 = ImageIO.read(getClass().getResourceAsStream("/data/0.png"));

        } catch (IOException e) {
            e.printStackTrace();
        }
        random = new Random();
        ens.add(RanDom());
        ens1.add(RanDom1());
    }
    public void update(){
        for (Enemy e1: ens1) {
            e1.update(1);
            if (e1.isOver() && !e1.isScore()){
                view.setScore(20);
                e1.setScore(true);
            }
            if (e1.Colision().intersects(character.Colision())){
                character.setLive(false);
                view.playSE(1);


            }}

        for (Enemy e: ens) {
            if (view.getScore() > -1 && view.getScore()<200){
                e.update(1);
            }else if (view.getScore() >= 200 && view.getScore()< 400){
                e.update(1.5);
            }else if (view.getScore() >= 400){
                e.update(2);
            }
            if (e.isOver() && !e.isScore()){
                view.setScore(20);
                e.setScore(true);
            }
            if (e.Colision().intersects(character.Colision())){
                character.setLive(false);
                view.playSE(1);


            }
        }
        Enemy firstE = ens.get(0);
        Enemy firstE1 = ens1.get(0);
        if (firstE.Out()){
            ens.remove(firstE);
            ens.add(RanDom());
        }
        if (firstE1.Out()){
            ens1.remove(firstE1);
            ens1.add(RanDom1());
        }

    }
    public void draw(Graphics g){
        for (Enemy e: ens) {
            e.draw(g);
        }
        for (Enemy e1: ens1
             ) {
            e1.draw(g);

        }
    }
    public void reset(){
        ens.clear();
        ens.add(RanDom());
        ens1.clear();
        ens1.add(RanDom1());
    }
    private OBJ_Cactus RanDom(){
        OBJ_Cactus cactus;

        cactus = new OBJ_Cactus(character);

        cactus.setX(700);

        if (random.nextBoolean()){

            cactus.setImg(imgCac1);
        }else {

            cactus.setImg(imgCac2);
        }

        return cactus;

    }
    private OBJ_Bird RanDom1(){
        OBJ_Bird bird;

        bird = new OBJ_Bird(character);

        bird.setX(800);

        if (random.nextBoolean()){

            bird.setImg(imgCacb1);
        }else {

            bird.setImg(imgCacb2);
        }

        return bird;

    }

}
