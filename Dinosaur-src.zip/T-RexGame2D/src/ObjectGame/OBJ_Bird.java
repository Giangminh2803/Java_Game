package ObjectGame;

import GameView.View;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;

public class OBJ_Bird extends Enemy{
    private BufferedImage img;
    private int posX, posY;
    private Rectangle rect;
    private OBJ_Character character;
    private boolean isScore = false;


    public OBJ_Bird(OBJ_Character character)
    {
        this.character = character;
        posX = 600;
        posY = 180;
        try {
            img = ImageIO.read(getClass().getResourceAsStream("/data/0.png"));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        rect = new Rectangle();

    }

    @Override
    public Rectangle Colision() {
        return rect;
    }

    @Override
    public void draw(Graphics g) {
        g.drawImage(img, posX,posY, null);

    }

    public void update(double i)
    {

        posX-=10*i;
        rect.x = posX;
        rect.y = posY;
        rect.width = img.getWidth()-10;
        rect.height = img.getHeight()-10;
    }

    public void setX(int x){
        posX = x;
    }
    public void setImg(BufferedImage img){
        this.img =img;
    }


    public void setScore()
    {

    }
    public boolean Out() {
        return (posX + img.getWidth() < 0);
    }
    @Override
    public boolean isOver(){
        return  character.getPosX() > posX;

    }
    @Override
    public boolean isScore()
    {
        return isScore;
    }
    public void setScore(boolean score)
    {
        this.isScore = score;
    }
}
