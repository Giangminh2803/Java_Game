package GameView;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.UnsupportedAudioFileException;
import java.io.IOException;
import java.net.URL;

public class Sound {
    Clip clip;
    URL sound[] = new URL[5];

    public Sound()
    {
        sound[0] = getClass().getResource("/data/jump1.wav");

        sound[1] = getClass().getResource("/data/dead.wav");



    }
    public void setUpFile(int i)
    {
        try {
            AudioInputStream soundInp = AudioSystem.getAudioInputStream(sound[i]);
            clip = AudioSystem.getClip();
            clip.open(soundInp);
        } catch (Exception e) {

        }
    }
    public void play()
    {
        clip.start();

    }
    public void stop()
    {
        clip.stop();
    }
}
