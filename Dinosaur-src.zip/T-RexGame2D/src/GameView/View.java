package GameView;

import ObjectGame.*;
import SQL_login.login;

import javax.imageio.ImageIO;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.Clip;
import javax.swing.*;


import java.applet.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.sql.*;

public class View extends JPanel implements Runnable, KeyListener{
    public static final int GAME_FIRST = 0;
    public static final int GAME_PLAY = 1;
    public static final int GAME_OVER = 2;

    public static final float limitY = 300;

    public static final float speedDrop = 1f;
    public static int diem;

    private int gameState = GAME_FIRST;
    private BufferedImage textOver, button;

    private OBJ_Character character;
    private OBJ_Way way;
    private OBJ_Bird bird;
    private EnemyManager enemyManager;
    public static int score = 0;
    private int hightScore;
    private Sound SE;

    public Thread thread;

    public View()  {

        character = new OBJ_Character();
        bird = new OBJ_Bird(character);
        character.setPosX(150);
        character.setPosY(200);
        SE = new Sound();
        way = new OBJ_Way(this);
        enemyManager = new EnemyManager(character, this);
        thread = new Thread(this);
        try {
            textOver = ImageIO.read(getClass().getResourceAsStream("/data/gameover_text.png"));
            button = ImageIO.read(getClass().getResourceAsStream("/data/replay_button.png"));
        } catch (Exception e) {
            e.printStackTrace();
        }
//        Statement stmt = null;
//
//        try {
//            ResultSet rs = stmt.executeQuery("SELECT Diem FROM diem");
//            diem = rs.getInt("Diem");
//            hightScore=diem;
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }


    }
    public void startGame()
    {
        thread.start();
    }

    @Override
    public void paint(Graphics g)
    {
        super.paint(g);
        g.setColor(Color.decode("#f7f7f7"));
        g.fillRect(0,0,getWidth(),getHeight());
        switch (gameState){
            case GAME_FIRST:
                character.draw(g);
                g.drawString("NO INTERNET MORE !!!",200,220);
                break;
            case GAME_PLAY:
                way.draw(g);
                enemyManager.draw(g);
                character.draw(g);
                g.drawString("SCORE: "+String.valueOf(score), 500,20);
                g.drawString("HIGHT SCORE: "+String.valueOf(hightScore), 500,40);
                break;
            case GAME_OVER:
                way.draw(g);
                enemyManager.draw(g);
                character.drawDead(g);
                g.drawImage(textOver,250,200,null);
                g.drawImage(button,325,230,null);
                g.drawString("SCORE: "+String.valueOf(score), 500,20);
                g.drawString("HIGHT SCORE: "+String.valueOf(hightScore), 500,40);
                break;
        }


    }

    @Override
    public void run() {
        while (true){
            try {
                updateGame();
                repaint();
                thread.sleep(18);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            } catch (SQLException e) {
                throw new RuntimeException(e);
            } catch (ClassNotFoundException e) {
                throw new RuntimeException(e);
            }
        }
    }
    public void updateGame()throws SQLException, ClassNotFoundException
    {
        switch (gameState){
            case GAME_PLAY:
                character.update();
                if (this.getScore()>-1 && this.getScore()< 200){
                    way.updateWay(1);
                } else if (this.getScore()>=200 && this.getScore()< 400) {
                    way.updateWay(1.5);
                } else if (this.getScore()>=400) {
                    way.updateWay(2);
                }
                enemyManager.update();
                if (!character.getLive()){
                    Connection conn = null;
                    Statement stmt = null;
                    try{
                        Class.forName(login.DRIVER_CLASS);
                        conn = DriverManager.getConnection(login.DB_URL, login.USER, login.PASS);

                        stmt = conn.createStatement();

                        ResultSet rs = stmt.executeQuery("SELECT Diem FROM diem");
//                        String sql="insert into diem(Diem)"+"values ("+getHightScore()+")";
//                        stmt.executeUpdate(sql);
                        String sql="Update diem Set Diem=? where Diem <?";
                        PreparedStatement pstmt = conn.prepareStatement(sql);
                        pstmt.setInt(1, hightScore);
                        pstmt.setInt(2, hightScore);
                        int rowAffected = pstmt.executeUpdate();
                        while (rs.next()) {
                            diem = rs.getInt("Diem");
                            System.out.print("Diem: " + diem+"\n");
                        }
                        rs.close();

                    }catch (Exception e){
                        e.printStackTrace();
                    }finally {
                        if (stmt != null)
                            stmt.close();
                        if (conn != null)
                            conn.close();
                    }
                    gameState =GAME_OVER;
                }
                break;
        }
    }
    public void resetGame()
    {
        character.setLive(true);
        character.setPosX(150);
        enemyManager.reset();
        resetScore();

    }
    public void setScore(int score){
        this.score += score;
        if (this.score > hightScore){
            hightScore = this.score;
        }


    }
    public void resetScore()
    {
        this.score = 0;
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
        switch (e.getKeyCode()){
            case KeyEvent.VK_SPACE:
                character.jump();

                break;
            case KeyEvent.VK_ESCAPE :
                if (gameState == GAME_PLAY){
                    gameState = GAME_OVER;
                    playSE(1);
                }

        }

    }

    @Override
    public void keyReleased(KeyEvent e) {
        switch (e.getKeyCode()){
            case KeyEvent.VK_SPACE:
                if (gameState == GAME_FIRST){
                    gameState = GAME_PLAY;
                }
                else {
                    playSE(0);
                }
                break;
            case KeyEvent.VK_ENTER:
                if (gameState == GAME_OVER) {
                    resetGame();
                    gameState = GAME_PLAY;
                }
                break;

        }

    }
    public void playSE(int i)
    {
        this.SE.setUpFile(i);
        this.SE.play();

    }


    public int getScore() {
        return score;
    }
    public int getHightScore() {
        {
            return hightScore;
        }

    }
}