package GameView;


import java.sql.*;
import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.nio.Buffer;


public class WindowPlay extends JFrame {
    private static View view;
    //    private int gameState;
    public WindowPlay()
    {
        super(" GAME 2D");
        setSize(700,500);
        setLocation(400,200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        view = new View();
        add(view);

        addKeyListener(view);
    }

    public void startGame()
    {
        view.startGame();
    }
    public static void main(String args[]) {
        WindowPlay wp = new WindowPlay();
        wp.setVisible(true);
        wp.startGame();
    }

}