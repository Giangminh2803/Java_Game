package SQL_login;

import java.sql.*;

public class login {
    public static final String DRIVER_CLASS = "com.mysql.cj.jdbc.Driver";
    public static final String DB_URL = "jdbc:mysql://localhost:3306/HH";
    public static final String USER = "root";
    public static final String PASS ="" ;
//    static final String PASS = "";

}